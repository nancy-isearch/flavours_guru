<?php
class ModelShippingCities extends Model {
public function addCities($data) {
	$query = $this->db->query("INSERT INTO " . DB_PREFIX . "shipping_cities SET name = '" . $this->db->escape($data['model']) . "', country = '" . $this->db->escape($data['country_id']) . "', state = '" . $this->db->escape($data['state_id']) . "', pincode = '" . $this->db->escape($data['pincode']) . "',  status = '" . (int)$data['status'] ."'");

		if($query)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function editCity($city_id, $data) {

		$query = $this->db->query("UPDATE " . DB_PREFIX . "shipping_cities SET name = '" . $this->db->escape($data['model']) . "', country = '" . $this->db->escape($data['country_id']) . "', state = '" . $this->db->escape($data['state_id']) . "', pincode = '" . $this->db->escape($data['pincode']) . "', status = '" . (int)$data['status'] . "' WHERE id = '" . (int)$city_id . "'");

		if($query)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public function deletecities($city_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "shipping_cities WHERE id = '" . (int)$city_id . "'");
		//$this->cache->delete('product');
	}

	public function getcity($city_id) {
		//$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "shipping_cities WHERE id = '" . (int)$city_id . "' ");
	$query = $this->db->query("select c.*, oz.name as ozname , occ.name as occname from ".DB_PREFIX."shipping_cities as c inner join ".DB_PREFIX."zone as oz on c.state = oz.zone_id inner join ".DB_PREFIX."country as occ on c.country = occ.country_id WHERE id = '" . (int)$city_id . "' ");
		return $query->row;
	}

	public function getCities($data = array()) {
		$sql = "select c.*, oz.name as ozname , occ.name as occname from ".DB_PREFIX."shipping_cities as c inner join ".DB_PREFIX."zone as oz on c.state = oz.zone_id inner join ".DB_PREFIX."country as occ on c.country = occ.country_id";
		
		if (!empty($data['filter_name'])) {
			$sql .= " WHERE c.name LIKE '%" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sql .= " GROUP BY id";
		
		$sort_data = array(
			'name',
			'state',
			'country',
			'pincode',
			'status'
		);

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}
		
		$query = $this->db->query($sql);
		return	$query->rows;
		
	}


	public function getTotalCities($data = array()) 
	{
		$sql = "SELECT COUNT(DISTINCT id) AS total FROM " . DB_PREFIX . "shipping_cities ";
		if (!empty($data['filter_name'])) 
		{
			$sql .= " WHERE name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}
		$query = $this->db->query($sql);
		return $query->row['total'];
	}
}
